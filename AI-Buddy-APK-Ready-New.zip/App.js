import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  StatusBar,
} from "react-native";

export default function App() {
  const [listening, setListening] = useState(false);
  const [status, setStatus] = useState("Ready to help");

  const handleMic = () => {
    if (listening) return;

    setListening(true);
    setStatus("Listening...");

    setTimeout(() => {
      setListening(false);
      setStatus("Ready to help");

      Alert.alert(
        "AI Buddy",
        "Voice demo ready hai.\nReal voice-to-text ke liye native speech setup chahiye."
      );
    }, 1800);
  };

  const askAI = () => {
    Alert.alert(
      "Ask AI",
      "Namaste! 👋 Main AI Buddy hoon.\n\nAap mujhse Hindi, Hinglish ya English me baat kar sakte ho."
    );
  };

  const createNote = () => {
    Alert.alert(
      "Create Note",
      "Note feature ready hai.\n\nYahan se aap apna note bana sakte ho."
    );
  };

  const setReminder = () => {
    Alert.alert(
      "Reminder",
      "Reminder feature ready hai.\n\nYahan reminder set kiya ja sakta hai."
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#050914" />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>AI Buddy</Text>
          <Text style={styles.subtitle}>
            Namaste! Main AI Buddy hoon.
          </Text>
        </View>

        <View style={styles.onlineDot} />
      </View>

      {/* AI Orb */}
      <View style={styles.orbArea}>
        <View style={styles.orbGlow}>
          <View style={styles.orb}>
            <Text style={styles.orbText}>AI</Text>
          </View>
        </View>

        <Text style={styles.status}>{status}</Text>
      </View>

      {/* Microphone */}
      <TouchableOpacity
        activeOpacity={0.8}
        style={[
          styles.micButton,
          listening && styles.micListening,
        ]}
        onPress={handleMic}
      >
        <Text style={styles.micIcon}>
          {listening ? "■" : "🎙"}
        </Text>
      </TouchableOpacity>

      <Text style={styles.micText}>
        {listening ? "Listening..." : "Tap the microphone to talk"}
      </Text>

      {/* Quick Actions */}
      <Text style={styles.sectionTitle}>Quick Actions</Text>

      <View style={styles.cardsRow}>
        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.card}
          onPress={askAI}
        >
          <Text style={styles.cardIcon}>✦</Text>
          <Text style={styles.cardTitle}>Ask AI</Text>
          <Text style={styles.cardText}>Chat</Text>
        </TouchableOpacity>

        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.card}
          onPress={createNote}
        >
          <Text style={styles.cardIcon}>📝</Text>
          <Text style={styles.cardTitle}>Note</Text>
          <Text style={styles.cardText}>Create</Text>
        </TouchableOpacity>

        <TouchableOpacity
          activeOpacity={0.8}
          style={styles.card}
          onPress={setReminder}
        >
          <Text style={styles.cardIcon}>⏰</Text>
          <Text style={styles.cardTitle}>Reminder</Text>
          <Text style={styles.cardText}>Set</Text>
        </TouchableOpacity>
      </View>

      {/* Bottom */}
      <View style={styles.bottom}>
        <Text style={styles.bottomText}>
          AI Buddy • Your personal AI assistant
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#050914",
    paddingHorizontal: 20,
  },

  header: {
    marginTop: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  title: {
    color: "#FFFFFF",
    fontSize: 30,
    fontWeight: "800",
  },

  subtitle: {
    color: "#8D9AAA",
    fontSize: 14,
    marginTop: 5,
  },

  onlineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: "#00E5FF",
    shadowColor: "#00E5FF",
    shadowOpacity: 0.9,
    shadowRadius: 10,
    elevation: 8,
  },

  orbArea: {
    alignItems: "center",
    marginTop: 65,
  },

  orbGlow: {
    width: 190,
    height: 190,
    borderRadius: 95,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#06253A",
    borderWidth: 2,
    borderColor: "#00D9FF",
    shadowColor: "#00D9FF",
    shadowOpacity: 0.8,
    shadowRadius: 30,
    elevation: 18,
  },

  orb: {
    width: 140,
    height: 140,
    borderRadius: 70,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#0A4563",
    borderWidth: 2,
    borderColor: "#58ECFF",
  },

  orbText: {
    color: "#FFFFFF",
    fontSize: 42,
    fontWeight: "900",
    letterSpacing: 2,
  },

  status: {
    color: "#67EFFF",
    fontSize: 16,
    marginTop: 20,
    fontWeight: "600",
  },

  micButton: {
    alignSelf: "center",
    marginTop: 28,
    width: 82,
    height: 82,
    borderRadius: 41,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#087BFF",
    borderWidth: 3,
    borderColor: "#45CFFF",
    shadowColor: "#008CFF",
    shadowOpacity: 0.8,
    shadowRadius: 18,
    elevation: 15,
  },

  micListening: {
    backgroundColor: "#00AFC7",
    borderColor: "#FFFFFF",
  },

  micIcon: {
    fontSize: 30,
    color: "#FFFFFF",
  },

  micText: {
    color: "#8997A8",
    textAlign: "center",
    fontSize: 14,
    marginTop: 12,
  },

  sectionTitle: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "700",
    marginTop: 45,
    marginBottom: 15,
  },

  cardsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  card: {
    width: "31.5%",
    minHeight: 105,
    borderRadius: 18,
    backgroundColor: "#101A29",
    borderWidth: 1,
    borderColor: "#1D3148",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 5,
  },

  cardIcon: {
    fontSize: 24,
    marginBottom: 7,
  },

  cardTitle: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "700",
  },

  cardText: {
    color: "#728196",
    fontSize: 11,
    marginTop: 3,
  },

  bottom: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    paddingBottom: 15,
  },

  bottomText: {
    color: "#465467",
    fontSize: 11,
  },
});