# AI Buddy APK Build

1. npm install
2. npx expo prebuild
3. npm install -g eas-cli
4. eas login
5. eas build -p android --profile preview

The preview profile is configured to create an installable Android APK.
